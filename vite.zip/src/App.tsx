import { Container, Stack } from "@mui/material";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import ProductCard from "./components/ProductCard";
import SearchBar from "./components/SearchBar";
import type { RootState } from "./redux";
import { getProductList } from "./redux/productsSlice";

function App() {
    const productList = useSelector((state: RootState) => state.products.value);

    const dispatch = useDispatch();

    useEffect(() => {
        async function fetchData() {
            dispatch(getProductList({}));
        }
        fetchData();
    }, [dispatch]);
    console.log(productList);
    return (
        <>
            <SearchBar />
            <Container sx={{ mt: 5 }}>
                <Stack direction={{ xs: "column", sm: "row" }} spacing={3}>
                    {productList.map((product) => (
                        <ProductCard key={product.id} name={product.name} price={product.price} originalPrice={product.originalPrice} rating={product.rating} image={product.image} discount={product.discount} />
                    ))}
                </Stack>
            </Container>
        </>
    );
}

export default App;
