import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { ProductService } from "../service/ProductService";

export interface InitialStateI {
    value: Array<ProductI>;
    amount: number;
}

export interface ProductI {
    id: string;
    name: string;
    price: number;
    originalPrice: number;
    rating: number;
    image: string;
    discount: string;
}

const initialState: InitialStateI = { value: [], amount: 0 };

const { actions, reducer } = createSlice({
    name: "products",
    initialState,
    reducers: {
        increaseAmount: (state) => {
            state.amount++;
        },
        decreaseAmount: (state) => {
            state.amount--;
        },
        setProductsData: (state, action) => {
            state.value = action.payload;
        },
    },
    extraReducers: (builder) => {
        builder.addCase(getProductList.fulfilled, () => {});
    },
});

const getProductList = createAsyncThunk("getProductList", async (params: object, ThunkAPI) => {
    const result = await ProductService.getProductList(params);
    if (result.data) ThunkAPI.dispatch(actions.setProductsData(result.data));

    return result;
});

export { getProductList, actions };

export default reducer;
