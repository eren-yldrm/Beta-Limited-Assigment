import axios from "axios";
import { URLS } from "./urls";

export const ProductService = {
    getProductList: (options: object) => axios.get(URLS.productService.getProduct, options),
};
