const base = "https://linkedin-cv-crawler.beta-limited.workers.dev/interview";

export const URLS = {
    productService: {
        getProduct: `${base}/products`,
    },
};
