import { Paper, InputBase, IconButton, Button } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";

export default function SearchBar() {
    return (
        <Paper sx={{ borderRadius: 8 }}>
            <IconButton sx={{ p: "10px" }}>
                <SearchIcon />
            </IconButton>
            <InputBase placeholder="Searching for..." />
            <Button sx={{ backgroundColor: "#b5525c", color: "#fff", borderTopRightRadius: "25px 25px", borderBottomRightRadius: "25px 25px" }}>Search</Button>
        </Paper>
    );
}
