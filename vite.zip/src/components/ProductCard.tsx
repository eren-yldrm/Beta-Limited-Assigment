import { Card, CardHeader, CardMedia, CardContent, Stack, Typography, IconButton, Rating, Chip } from "@mui/material";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../redux";
import { useCallback } from "react";
import { actions as productActions } from "../redux/productsSlice";

type props = {
    name: string;
    originalPrice: number;
    price: number;
    rating: number;
    image: string;
    discount: string;
};

export default function ProductCard({ name, originalPrice, price, rating, image, discount }: props) {
    const dispatch = useDispatch();
    const amount = useSelector((state: RootState) => state.products.amount);

    const addToCard = useCallback(() => {
        dispatch(productActions.increaseAmount());
    }, [dispatch]);

    const removeToCard = useCallback(() => {
        dispatch(productActions.decreaseAmount());
    }, [dispatch]);

    return (
        <Card>
            <CardHeader avatar={<Chip label={discount} sx={{ bgcolor: "#b5525c", color: "#fff" }} />} />
            <CardMedia component="img" height="194" width="300" image={image} alt={name} />
            <CardContent>
                <Stack direction="row" justifyContent="space-between" alignItems="center">
                    <Stack spacing={2}>
                        <Typography>{name}</Typography>
                        <Stack direction="row" alignItems="center" spacing={1}>
                            <Rating name="rating" value={rating} readOnly />
                            <Typography>({rating})</Typography>
                        </Stack>
                        <Stack direction="row" spacing={1}>
                            <Typography sx={{ color: "red" }}>${price}</Typography>
                            <Typography sx={{ color: "grey", textDecorationLine: "line-through" }}>${originalPrice}</Typography>
                        </Stack>
                    </Stack>
                    <Stack alignItems="center">
                        {amount > 0 && (
                            <>
                                <IconButton onClick={removeToCard} sx={{ color: "red", border: "1px solid red", borderRadius: 1 }}>
                                    <RemoveIcon />
                                </IconButton>
                                <Typography>{amount}</Typography>
                            </>
                        )}
                        <IconButton onClick={addToCard} sx={{ color: "red", border: "1px solid red", borderRadius: 1 }}>
                            <AddIcon />
                        </IconButton>
                    </Stack>
                </Stack>
            </CardContent>
        </Card>
    );
}
